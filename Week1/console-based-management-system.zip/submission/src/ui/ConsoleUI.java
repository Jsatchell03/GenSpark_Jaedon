package ui;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.Collection;
import java.util.Scanner;
import java.util.Set;

import models.*;


public class ConsoleUI {
    private Scanner input = new Scanner(System.in);

    public int promptMenuChoice(String prompt, int max) {
        System.out.print(prompt);
        int choice = input.nextInt();
        while (choice < 1 || choice > max) {
            System.out.printf("Invalid Selection: Enter a number from 1 - %d.\n", max);
            System.out.print("Enter your selection to continue: ");
            choice = input.nextInt();
        }
        input.nextLine();
        return choice;
    }

    public int openMainMenu() {
        return promptMenuChoice(
                "--- Employee Management System Console ---\n" +
                        "1. Employee Management Menu\n" +
                        "2. Workplace Management Menu\n" +
                        "3. Assignment Menu\n" +
                        "4. Close System\n" +
                        "Enter your selection to continue: ",
                4
        );
    }

    public int openEmployeeManagementMenu() {
        return promptMenuChoice(
                "--- Employee Management Menu ---\n" +
                        "1. View All Employee Records\n" +
                        "2. View One Employee Record\n" +
                        "3. Add New Employee Record\n" +
                        "4. Add New Manager Record\n" +
                        "5. Update Employee Record\n" +
                        "6. Delete Employee Record\n" +
                        "7. Return To Main Menu\n" +
                        "Enter your selection to continue: ",
                7
        );
    }

    public int openWorkplaceManagementMenu() {
        return promptMenuChoice(
                "--- Workplace Management Menu ---\n" +
                        "1. View All Workplace Records\n" +
                        "2. View One Workplace Record\n" +
                        "3. Add New Workplace Record\n" +
                        "4. Update Workplace Record\n" +
                        "5. Delete Workplace Record\n" +
                        "6. Return To Main Menu\n" +
                        "Enter your selection to continue: ",
                6
        );
    }

    public int openAssignmentMenu() {
        return promptMenuChoice(
                "--- Assignment Management Menu ---\n" +
                        "1. Assign Employee to Workplace\n" +
                        "2. Remove Employee from Workplace\n" +
                        "3. View Employee's Assigned Workplaces\n" +
                        "4. View Workplace's Assigned Employees\n" +
                        "5. Return To Main Menu\n" +
                        "Enter your selection to continue: ",
                5
        );
    }

    public <T extends BaseRecord> void printAllRecords(Collection<T> records) {
        if (records.isEmpty()) {
            System.out.println("No records found.");
            return;
        }

        for (BaseRecord record : records) {
            System.out.println(record.toString());
        }
    }

    public void printRecord(BaseRecord record) {
        System.out.println(record.toString());
    }

    public void pause() {
        System.out.print("Press enter to continue...");
        input.nextLine();
    }

    public int promptID(String prompt, Set<Integer> validIds) {
        int id;
        while (true) {
            System.out.print(prompt);
            id = input.nextInt();
            if (validateID(id, validIds)) {
                input.nextLine();
                return id;
            }
        }
    }

    public String promptString(String prompt) {
        String str;
        while (true) {
            System.out.print(prompt);
            str = input.nextLine();
            if (!str.isEmpty()) {
                return str;
            }
            System.out.println("Invalid String: Input cannot be empty.");
        }

    }

    public Date promptDate(String prompt) {
        String dateStr;
        while (true) {
            System.out.print(prompt);
            dateStr = input.nextLine();
            if (validateDate(dateStr)) {
                return new Date(dateStr);
            }
        }
    }

    public boolean validateDate(String dateStr) {
        try {
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM-dd-yyyy");
            LocalDate.parse(dateStr, formatter);
            return true;
        } catch (DateTimeParseException e) {
            System.out.printf("Invalid Date '%s'.\n", dateStr);
            return false;
        }
    }

    public boolean validateID(int id, Set<Integer> validIds) {
        if (id < 0) {
            System.out.printf("Invalid ID '%d': ID cannot be negative.\n", id);
            return false;
        }

        if (!validIds.contains(id)) {
            System.out.printf("Invalid ID '%d': No matching ID found.\n", id);
            return false;
        }
        return true;

    }
}
