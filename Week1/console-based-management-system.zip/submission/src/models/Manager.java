package models;

import java.util.HashSet;

public class Manager extends Employee {
    private String department;

    public Manager(int id, String name, Date hireDate, String department) {
        super(id, name, hireDate);
        this.department = department;
    }

    public Manager(int id, String name, Date hireDate, HashSet<Integer> assignedWorkplaces, String department) {
        super(id, name, hireDate, assignedWorkplaces);
        this.department = department;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    @Override
    public String toString() {
        return String.format("%d | %s | %s | Department: %s", getId(), getName(), getHireDate().toString(), department);
    }
}
