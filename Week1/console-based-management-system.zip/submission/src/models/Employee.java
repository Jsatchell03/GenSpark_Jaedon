package models;

import java.util.HashSet;


public class Employee extends BaseRecord {
    private int id;
    private String name;
    private Date hireDate;
    private HashSet<Integer> assignedWorkplaces;

    public Employee(int id, String name, Date hireDate) {
        this.id = id;
        this.name = name;
        this.hireDate = hireDate;
        this.assignedWorkplaces = new HashSet<>();
    }

    public Employee(int id, String name, Date hireDate, HashSet<Integer> assignedWorkplaces) {
        this.id = id;
        this.name = name;
        this.hireDate = hireDate;
        this.assignedWorkplaces = assignedWorkplaces;
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Date getHireDate() {
        return hireDate;
    }

    public void setHireDate(Date hireDate) {
        this.hireDate = hireDate;
    }

    public HashSet<Integer> getAssignedWorkplaces() {
        return assignedWorkplaces;
    }

    @Override
    public String toString() {
        return String.format("%d | %s | %s", id, name, hireDate.toString());
    }

    public void assignToWorkplace(int workplaceId) {
        if (assignedWorkplaces.contains(workplaceId)) {
            System.out.println("Employee is already assigned to this workplace.");
        } else {
            assignedWorkplaces.add(workplaceId);
        }
    }

    public void removeFromWorkplace(int workplaceId) {
        if (!assignedWorkplaces.contains(workplaceId)) {
            System.out.println("Employee is not assigned to this workplace.");
        } else {
            assignedWorkplaces.remove(workplaceId);
        }
    }
}
