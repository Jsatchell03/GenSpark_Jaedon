package models;

import java.util.HashSet;

public class Workplace extends BaseRecord {
    private int id;
    private String location;
    private HashSet<Integer> assignedEmployees;

    public Workplace(int id, String location, HashSet<Integer> assignedEmployees) {
        this.id = id;
        this.location = location;
        this.assignedEmployees = assignedEmployees;
    }

    public Workplace(int id, String location) {
        this.id = id;
        this.location = location;
        this.assignedEmployees = new HashSet<Integer>();
    }

    public int getId() {
        return id;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public HashSet<Integer> getAssignedEmployees() {
        return assignedEmployees;
    }

    @Override
    public String toString() {
        return String.format("%d | %s", id, location);
    }

    public void assignEmployee(int employeeId) {
        if (assignedEmployees.contains(employeeId)) {
            System.out.println("Employee is already assigned to this workplace.");
        } else {
            assignedEmployees.add(employeeId);
        }
    }

    public void removeEmployee(int employeeId) {
        if (!assignedEmployees.contains(employeeId)) {
            System.out.println("Employee is not assigned to this workplace.");
        } else {
            assignedEmployees.remove(employeeId);
        }
    }
}
