package app;

import models.*;
import ui.ConsoleUI;
import database.*;

import java.util.HashMap;

public class EmployeeManagementSystem {
    private HashMap<Integer, Employee> employees = new HashMap<Integer, Employee>();
    private HashMap<Integer, Workplace> workplaces = new HashMap<Integer, Workplace>();
    private ConsoleUI ui = new ConsoleUI();
    private EmployeeDatabase employeeDB = new EmployeeDatabase();
    private WorkplaceDatabase workplaceDB = new WorkplaceDatabase();

    public EmployeeManagementSystem() {

    }

    public void run() {
        employees = employeeDB.load();
        workplaces = workplaceDB.load();
        int choice;
        while (true) {
            choice = ui.openMainMenu();
            switch (choice) {
                case 1 -> manageEmployees();
                case 2 -> manageWorkplaces();
                case 3 -> manageAssignments();
                case 4 -> {
                    return;
                }
            }
        }
    }

    private void manageEmployees() {
        int choice;
        while (true) {
            choice = ui.openEmployeeManagementMenu();
            switch (choice) {
                case 1 -> {
                    ui.printAllRecords(employees.values());
                    ui.pause();
                }

                case 2 -> {
                    ui.printRecord(employees.get(ui.promptID("Enter employee ID: ", employees.keySet())));
                    ui.pause();
                }

                case 3 -> {
                    Employee newEmployee = new Employee(employeeDB.getNewId(), ui.promptString("Enter employee name: "), ui.promptDate("Enter hire date (MM-DD-YYYY): "));
                    employees.put(newEmployee.getId(), newEmployee);
                    employeeDB.save(employees);
                    ui.pause();
                }

                case 4 -> {
                    Manager newManager = new Manager(employeeDB.getNewId(), ui.promptString("Enter manager name: "), ui.promptDate("Enter hire date (MM-DD-YYYY): "), ui.promptString("Enter department: "));
                    employees.put(newManager.getId(), newManager);
                    employeeDB.save(employees);
                    ui.pause();
                }

                case 5 -> {
                    int updateID = ui.promptID("Enter employee ID: ", employees.keySet());
                    ui.printRecord(employees.get(updateID));
                    Employee currentEmployee = employees.get(updateID);
                    
                    if (currentEmployee instanceof Manager) {
                        Manager updatedManager = new Manager(updateID, ui.promptString("Enter updated manager name: "), ui.promptDate("Enter updated hire date (MM-DD-YYYY): "), currentEmployee.getAssignedWorkplaces(), ui.promptString("Enter updated department: "));
                        employees.put(updatedManager.getId(), updatedManager);
                    } else {
                        Employee updatedEmployee = new Employee(updateID, ui.promptString("Enter updated employee name: "), ui.promptDate("Enter updated hire date (MM-DD-YYYY): "), currentEmployee.getAssignedWorkplaces());
                        employees.put(updatedEmployee.getId(), updatedEmployee);
                    }
                    employeeDB.save(employees);
                    ui.pause();
                }

                case 6 -> {
                    int deleteID = ui.promptID("Enter employee ID: ", employees.keySet());
                    for (int workplaceID : employees.get(deleteID).getAssignedWorkplaces()) {
                        workplaces.get(workplaceID).removeEmployee(deleteID);
                    }
                    employees.remove(deleteID);
                    employeeDB.save(employees);
                    workplaceDB.save(workplaces);
                    ui.pause();
                }

                case 7 -> {
                    return;
                }
            }
        }
    }

    private void manageWorkplaces() {
        int choice;
        while (true) {
            choice = ui.openWorkplaceManagementMenu();
            switch (choice) {
                case 1 -> {
                    ui.printAllRecords(workplaces.values());
                    ui.pause();
                }

                case 2 -> {
                    ui.printRecord(workplaces.get(ui.promptID("Enter workplace ID: ", workplaces.keySet())));
                    ui.pause();
                }

                case 3 -> {
                    Workplace newWorkplace = new Workplace(workplaceDB.getNewId(), ui.promptString("Enter workplace location: "));
                    workplaces.put(newWorkplace.getId(), newWorkplace);
                    workplaceDB.save(workplaces);
                    ui.pause();
                }

                case 4 -> {
                    int updateID = ui.promptID("Enter workplace ID: ", workplaces.keySet());
                    ui.printRecord(workplaces.get(updateID));
                    Workplace updatedWorkplace = new Workplace(updateID, ui.promptString("Enter updated workplace location: "));
                    workplaces.put(updatedWorkplace.getId(), updatedWorkplace);
                    workplaceDB.save(workplaces);
                    ui.pause();
                }

                case 5 -> {
                    int deleteID = ui.promptID("Enter workplace ID: ", workplaces.keySet());
                    for (int employeeID : workplaces.get(deleteID).getAssignedEmployees()) {
                        employees.get(employeeID).removeFromWorkplace(deleteID);
                    }
                    workplaces.remove(deleteID);
                    workplaceDB.save(workplaces);
                    employeeDB.save(employees);
                    ui.pause();
                }

                case 6 -> {
                    return;
                }
            }
        }
    }

    private void manageAssignments() {
        int choice;
        while (true) {
            choice = ui.openAssignmentMenu();
            switch (choice) {
                case 1 -> {
                    int employeeID = ui.promptID("Enter employee ID: ", employees.keySet());
                    int workplaceID = ui.promptID("Enter workplace ID: ", workplaces.keySet());
                    workplaces.get(workplaceID).assignEmployee(employeeID);
                    employees.get(employeeID).assignToWorkplace(workplaceID);
                    workplaceDB.save(workplaces);
                    employeeDB.save(employees);
                    ui.pause();
                }

                case 2 -> {
                    int employeeID = ui.promptID("Enter employee ID: ", employees.keySet());
                    int workplaceID = ui.promptID("Enter workplace ID: ", employees.get(employeeID).getAssignedWorkplaces());
                    workplaces.get(workplaceID).removeEmployee(employeeID);
                    employees.get(employeeID).removeFromWorkplace(workplaceID);
                    workplaceDB.save(workplaces);
                    employeeDB.save(employees);
                    ui.pause();
                }

                case 3 -> {
                    for (int workplaceID : employees.get(ui.promptID("Enter employee ID: ", employees.keySet())).getAssignedWorkplaces()) {
                        ui.printRecord(workplaces.get(workplaceID));
                    }
                    ui.pause();
                }

                case 4 -> {
                    for (int employeeID : workplaces.get(ui.promptID("Enter workplace ID: ", workplaces.keySet())).getAssignedEmployees()) {
                        ui.printRecord(employees.get(employeeID));
                    }
                    ui.pause();
                }

                case 5 -> {
                    return;
                }
            }
        }
    }

}
