package database;

import models.Date;
import models.Employee;
import models.Manager;

import java.io.*;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.stream.Collectors;

public class EmployeeDatabase {
    private final String FILE_PATH = "data/employees.txt";
    private int autoCount;

    public EmployeeDatabase() {
        this.autoCount = 0;
    }

    public HashMap<Integer, Employee> load() {
        HashMap<Integer, Employee> employees = new HashMap<Integer, Employee>();
        try (BufferedReader reader = new BufferedReader(new FileReader(FILE_PATH))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] record = line.split(",");
                int id = Integer.parseInt(record[0]);
                autoCount = Math.max(autoCount, id);
                String name = record[1];
                Date hireDate = new Date(record[2]);
                HashSet<Integer> workplaces;
                if (record[3].equals("-1")) {
                    workplaces = new HashSet<Integer>();
                } else {
                    workplaces = Arrays.stream(record[3].split(";"))
                            .map(Integer::parseInt)
                            .collect(Collectors.toCollection(HashSet::new));
                }
                
                if (record.length > 4 && !record[4].isEmpty()) {
                    String department = record[4];
                    employees.put(id, new Manager(id, name, hireDate, workplaces, department));
                } else {
                    employees.put(id, new Employee(id, name, hireDate, workplaces));
                }
            }
        } catch (IOException e) {
            System.err.println("Error reading file: " + e.getMessage());
        }
        return employees;
    }

    public void save(Map<Integer, Employee> employees) {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(FILE_PATH))) {
            for (Employee employee : employees.values()) {
                String workplaces = employee.getAssignedWorkplaces().stream()
                        .map(Object::toString)
                        .collect(Collectors.joining(";"));
                if (workplaces.isEmpty()) {
                    workplaces = "-1";
                }
                
                if (employee instanceof Manager) {
                    Manager manager = (Manager) employee;
                    bw.write(String.format("%d,%s,%s,%s,%s\n",
                            employee.getId(), employee.getName(), employee.getHireDate().toString(), 
                            workplaces, manager.getDepartment()));
                } else {
                    bw.write(String.format("%d,%s,%s,%s,\n",
                            employee.getId(), employee.getName(), employee.getHireDate().toString(), workplaces));
                }
            }
        } catch (IOException e) {
            System.err.format("IOException: %s%n", e);
        }
    }

    public int getAutoCount() {
        return autoCount;
    }

    public int getNewId() {
        autoCount += 1;
        return autoCount;
    }
}
