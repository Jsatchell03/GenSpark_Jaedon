package database;

import models.Workplace;

import java.io.*;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.stream.Collectors;

public class WorkplaceDatabase {
    private final String FILE_PATH = "data/workplaces.txt";
    private int autoCount;

    public WorkplaceDatabase() {
        autoCount = 0;
    }

    public HashMap<Integer, Workplace> load() {
        HashMap<Integer, Workplace> workplaces = new HashMap<Integer, Workplace>();
        try (BufferedReader reader = new BufferedReader(new FileReader(FILE_PATH))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] record = line.split(",");
                int id = Integer.parseInt(record[0]);
                autoCount = Math.max(id, autoCount);
                String location = record[1];
                HashSet<Integer> employees;
                if (record[2].equals("-1")) {
                    employees = new HashSet<Integer>();
                } else {
                    employees = Arrays.stream(record[2].split(";"))
                            .map(Integer::parseInt)
                            .collect(Collectors.toCollection(HashSet::new));
                }
                workplaces.put(id, new Workplace(id, location, employees));
            }
        } catch (IOException e) {
            System.err.println("Error reading file: " + e.getMessage());
        }
        return workplaces;
    }

    public int getAutoCount() {
        return autoCount;
    }

    public int getNewId() {
        autoCount += 1;
        return autoCount;
    }

    public void save(HashMap<Integer, Workplace> workplaces) {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(FILE_PATH))) {
            for (Workplace workplace : workplaces.values()) {
                String employees = workplace.getAssignedEmployees().stream()
                        .map(Object::toString)
                        .collect(Collectors.joining(";"));
                if (employees.isEmpty()) {
                    employees = "-1";
                }
                bw.write(String.format("%d,%s,%s\n",
                        workplace.getId(), workplace.getLocation(), employees));
            }
        } catch (IOException e) {
            System.err.format("IOException: %s%n", e);
        }
    }


}
