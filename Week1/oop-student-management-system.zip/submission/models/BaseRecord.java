package models;

public abstract class BaseRecord {
    @Override
    abstract public String toString();
}
